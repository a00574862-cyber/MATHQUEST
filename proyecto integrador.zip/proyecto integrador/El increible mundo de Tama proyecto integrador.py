import tkinter as tk
from tkinter import simpledialog
from tkinter import messagebox
from PIL import Image, ImageDraw, ImageFont
import random
import fractions
import time
import math
import matplotlib.pyplot as plt

# Función principal para temas de primero de secundaria
def primero_secu(nombre, cajero, intentos, puntaje_final, tiempo):
    for widget in ventana.winfo_children():
        widget.destroy()
    
    # Fondo de pantalla
    fondo = tk.Label(ventana, image=fondo_primero_de_secundaria)
    fondo.place(x=0, y=0)
    
    boton_1 = tk.Frame(ventana, bg="white")
    boton_1.place(relx=0.5, rely=0.265, anchor="center")
    
    boton_1ro = tk.Button(boton_1, text="Operaciones con Fracciones", command=lambda: secundaria1fracciones(nombre, cajero, intentos, puntaje_final, tiempo), bg="gray", borderwidth=10, font=("Magic R", 25, "bold"))
    boton_1ro.pack()
    
    boton_2 = tk.Frame(ventana, bg="white")
    boton_2.place(relx=0.5, rely=0.495, anchor="center")
    
    boton_2do = tk.Button(boton_2, text="Potencias", command=lambda: secundaria1potencia(nombre, cajero, intentos, puntaje_final, tiempo), bg="gray", borderwidth=10, font=("Magic R", 25, "bold"))
    boton_2do.pack()
    
    boton_3 = tk.Frame(ventana, bg="white")
    boton_3.place(relx=0.5, rely=0.735, anchor="center")
    
    boton_3ro = tk.Button(boton_3, text="Porcentajes y Proporciones", command=lambda: secundaria1porcentajes_proporciones(nombre, cajero, intentos, puntaje_final, tiempo), bg="gray", borderwidth=10, font=("Magic R", 25, "bold"))
    boton_3ro.pack()
    
    boton = tk.Frame(ventana, bg="white")
    boton.place(relx=0.5, rely=0.9, anchor="center")
    
    boton_regresar = tk.Button(boton, text="Regresar", command=lambda: opciones_grado(nombre, cajero, intentos, puntaje_final, tiempo), bg="orange", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_regresar.pack()

# Función para manejar el juego de porcentajes y proporciones
def secundaria1porcentajes_proporciones(nombre, cajero, intentos, puntaje_final, tiempo):
    for widget in ventana.winfo_children():
        widget.destroy()

    ventana.title("El increible mundo de Tama")
    ventana.geometry("1080x720")
    ventana.resizable(False, False)

    fondo = tk.Label(ventana, image=fondo_primero_de_secundaria)
    fondo.place(x=0, y=0)

    intentos[0][2] += 1
    contador = 0
    pregunta_numero = 0
    start_time = time.time()

    def verificar_respuesta(resultado, respuesta_elegida):
        nonlocal contador, pregunta_numero, cajero, start_time
        if abs(respuesta_elegida - resultado) < 0.01:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
            cajero += 20
        else:
            messagebox.showerror("Incorrecto", f"Respuesta incorrecta. La respuesta correcta era {resultado:.2f}.")

        pregunta_numero += 1
        if pregunta_numero < 5:
            nueva_pregunta()
        else:
            elapsed_time = time.time() - start_time
            finalizar_juego(elapsed_time)

    def nueva_pregunta():
        tipo = random.choice(['porcentaje', 'proporcion'])

        if tipo == 'porcentaje':
            total = random.randint(50, 500)
            porcentaje = random.randint(1, 100)
            resultado = total * (porcentaje / 100)
            pregunta.config(text=f"¿Cuál es el {porcentaje}% de {total}?")
        else:
            num1, num2 = random.randint(1, 10), random.randint(1, 10)
            num3 = random.randint(1, 10)
            resultado = (num3 * num2) / num1
            pregunta.config(text=f"Si {num1} es a {num2}, ¿cuánto es {num3} en la misma proporción?")

        opciones_respuesta = [resultado, random.uniform(1, 500), random.uniform(1, 500), random.uniform(1, 500)]
        random.shuffle(opciones_respuesta)

        for i, opcion in enumerate(opciones):
            opciones[i].config(text=f"{opciones_respuesta[i]:.2f}", command=lambda opt=opciones_respuesta[i]: verificar_respuesta(resultado, opt))

    def finalizar_juego(elapsed_time):
        for widget in ventana.winfo_children():
            widget.destroy()
        puntaje_final[0][2].append(contador)
        tiempo[0][2].append(elapsed_time)
        primero_secu(nombre, cajero, intentos, puntaje_final, tiempo)

    pregunta_frame = tk.Frame(ventana, bg="black")
    pregunta_frame.place(relx=0.5, rely=0.235, anchor="center")

    pregunta = tk.Label(pregunta_frame, text="", font=("Arial", 22), bg="beige", fg="black")
    pregunta.pack(padx=10, pady=10)

    opciones = [tk.Button(ventana, text="", font=("Arial", 14), borderwidth=10, bg="beige") for _ in range(4)]
    for i, opcion in enumerate(opciones):
        opcion.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")

    nueva_pregunta()

# Función que se encarga de manejar el juego de potencias
def secundaria1potencia(nombre, cajero, intentos, puntaje_final, tiempo):
    for widget in ventana.winfo_children():
        widget.destroy()

    fondo = tk.Label(ventana, image=fondo_primero_de_secundaria)
    fondo.place(x=0, y=0)

    intentos[0][1] += 1
    contador = 0
    pregunta_numero = 0
    start_time = time.time()

    def verificar_respuesta(a, b, respuesta_elegida):
        nonlocal contador, pregunta_numero, cajero, start_time
        if a ** b == respuesta_elegida:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
            cajero += 20
        else:
            messagebox.showerror("Incorrecto", f"Respuesta incorrecta. La potencia correcta es {a ** b}.")
        
        pregunta_numero += 1
        if pregunta_numero < 5:
            nueva_pregunta()
        else:
            elapsed_time = time.time() - start_time
            finalizar_juego(elapsed_time)

    def nueva_pregunta():
        a = random.randint(1, 10)
        b = random.randint(2, 3)
        opciones = [a ** b, random.randint(1, 100), random.randint(1, 100), random.randint(1, 100)]
        random.shuffle(opciones)

        pregunta.config(text=f"¿Cuál es {a} elevado a la {b}?")
        for i, opcion in enumerate(opciones):
            botones[i].config(text=str(opcion), command=lambda opcion=opcion: verificar_respuesta(a, b, opcion))

    def finalizar_juego(elapsed_time):
        for widget in ventana.winfo_children():
            widget.destroy()
        puntaje_final[0][1].append(contador)
        tiempo[0][1].append(elapsed_time)
        primero_secu(nombre, cajero, intentos, puntaje_final, tiempo)

    pregunta_frame = tk.Frame(ventana, bg="black")
    pregunta_frame.place(relx=0.5, rely=0.235, anchor="center")

    pregunta = tk.Label(pregunta_frame, text="", font=("Arial", 22), bg="beige", fg="black", borderwidth=5, relief="solid")
    pregunta.pack(padx=10, pady=10)

    botones = [tk.Button(ventana, text="", font=("Arial", 14), width=15, height=2, bg="beige", borderwidth=10) for _ in range(4)]
    for i, boton in enumerate(botones):
        boton.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")

    nueva_pregunta()

# Función para el juego de fracciones
def secundaria1fracciones(nombre, cajero, intentos, puntaje_final, tiempo):
    for widget in ventana.winfo_children():
        widget.destroy()
    
    fondo = tk.Label(ventana, image=fondo_primero_de_secundaria)
    fondo.place(x=0, y=0)

    intentos[0][0] += 1
    contador = 0
    pregunta_numero = 0
    start_time = time.time()

    def verificar_respuesta(fraccion1, operador, fraccion2, respuesta_correcta, seleccion_usuario):
        nonlocal contador, pregunta_numero, cajero, start_time
        if seleccion_usuario == respuesta_correcta:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
            cajero += 20
        else:
            messagebox.showerror("Incorrecto", f"Respuesta incorrecta. La respuesta correcta era {respuesta_correcta}.")

        pregunta_numero += 1
        if pregunta_numero < 5:
            nueva_pregunta()
        else:
            elapsed_time = time.time() - start_time
            finalizar_juego(elapsed_time)

    def nueva_pregunta():
        num1, den1 = random.randint(1, 10), random.randint(1, 10)
        num2, den2 = random.randint(1, 10), random.randint(1, 10)
        fraccion1 = fractions.Fraction(num1, den1)
        fraccion2 = fractions.Fraction(num2, den2)
        operadores = ['+', '-', '*', '/']
        operador = random.choice(operadores)

        if operador == '+':
            respuesta_correcta = fraccion1 + fraccion2
        elif operador == '-':
            respuesta_correcta = fraccion1 - fraccion2
        elif operador == '*':
            respuesta_correcta = fraccion1 * fraccion2
        else:
            respuesta_correcta = fraccion1 / fraccion2

        opciones_respuesta = [respuesta_correcta]
        while len(opciones_respuesta) < 4:
            opcion_falsa = fractions.Fraction(random.randint(1, 10), random.randint(1, 10))
            if opcion_falsa not in opciones_respuesta:
                opciones_respuesta.append(opcion_falsa)

        random.shuffle(opciones_respuesta)

        pregunta.config(text=f"¿Cuánto es {fraccion1} {operador} {fraccion2}?")
        for i, opcion in enumerate(opciones):
            opciones[i].config(
                text=f"{opciones_respuesta[i]}",
                command=lambda opt=opciones_respuesta[i]: verificar_respuesta(fraccion1, operador, fraccion2, respuesta_correcta, opt), bg="beige", width=15, height=2, borderwidth=10)

    def finalizar_juego(elapsed_time):
        for widget in ventana.winfo_children():
            widget.destroy()
        puntaje_final[0][0].append(contador)
        tiempo[0][0].append(elapsed_time)
        primero_secu(nombre, cajero, intentos, puntaje_final, tiempo)

    pregunta_frame = tk.Frame(ventana, bg="black")
    pregunta_frame.place(relx=0.5, rely=0.235, anchor="center")

    pregunta = tk.Label(pregunta_frame, text="", font=("Arial", 22), bg="beige", fg="black")
    pregunta.pack(padx=10, pady=10)

    opciones = [tk.Button(ventana, text="", font=("Arial", 14), borderwidth=10, bg="beige") for _ in range(4)]
    for i, opcion in enumerate(opciones):
        opcion.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")

    nueva_pregunta()

# Ejemplo de función para el examen final de primero de secundaria
def examen_final_primero(nombre, cajero, intentos, puntaje_final, tiempo):
    ventana.title("Examen Final de Primero de Secundaria")
    ancho = 1080
    alto = 720
    ventana.geometry(f"{ancho}x{alto}")
    ventana.resizable(False, False)

    fondo = tk.Label(ventana, image=fondo_examenes)
    fondo.place(x=0, y=0)

    contador = 0
    pregunta_numero = 0
    start_time = time.time()
    intentos[3][0] += 1

    def verificar_respuesta(resultado_real, respuesta_elegida):
        nonlocal pregunta_numero, contador, cajero
        if abs(respuesta_elegida - resultado_real) < 0.01:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
            cajero += 20
        else:
            messagebox.showerror("Incorrecto", f"Incorrecto. La respuesta correcta era {resultado_real}.")
        pregunta_numero += 1
        if pregunta_numero < 10:
            nueva_pregunta()
        else:
            mostrar_resultado_final(contador)

    def nueva_pregunta():
        if pregunta_numero < 3:
            num1, den1 = random.randint(1, 10), random.randint(1, 10)
            num2, den2 = random.randint(1, 10), random.randint(1, 10)
            fraccion1 = fractions.Fraction(num1, den1)
            fraccion2 = fractions.Fraction(num2, den2)
            operador = random.choice(['+', '-', '*', '/'])
            if operador == '+':
                resultado_real = fraccion1 + fraccion2
            elif operador == '-':
                resultado_real = fraccion1 - fraccion2
            elif operador == '*':
                resultado_real = fraccion1 * fraccion2
            else:
                resultado_real = fraccion1 / fraccion2
            pregunta_label.config(text=f"¿Cuánto es {fraccion1} {operador} {fraccion2}?")
        elif pregunta_numero < 6:
            total = random.randint(50, 500)
            porcentaje = random.randint(1, 100)
            resultado_real = round(total * (porcentaje / 100), 2)
            pregunta_label.config(text=f"¿Cuál es el {porcentaje}% de {total}?")
        else:
            base = random.randint(1, 10)
            exponente = random.randint(2, 3)
            resultado_real = base ** exponente
            pregunta_label.config(text=f"¿Cuánto es {base} elevado a la {exponente}?")

        opciones = [resultado_real, random.uniform(1, 100), random.uniform(1, 100), random.uniform(1, 100)]
        random.shuffle(opciones)

        for i, opcion in enumerate(opciones):
            botones[i].config(text=f"{opcion:.2f}", command=lambda opcion=opcion: verificar_respuesta(resultado_real, opcion))

    def mostrar_resultado_final(contador):
        for widget in ventana.winfo_children():
            widget.destroy()

        fondo = tk.Label(ventana, image=fondo_examenes)
        fondo.place(x=0, y=0)

        resultado_label = tk.Label(ventana, text=f"¡Examen Final Completado!\nPuntaje: {contador} respuestas correctas", font=("Arial", 22), bg="dark goldenrod", fg="black")
        resultado_label.place(relx=0.5, rely=0.3, anchor="center")

        puntaje_final[3][0].append(contador)
        tiempo[3][0].append(time.time() - start_time)

        regresar_button = tk.Button(ventana, text="Regresar a Exámenes", font=("Arial", 16), bg="dark goldenrod", fg="black", command=lambda: examen_secu(nombre, cajero, intentos, puntaje_final, tiempo))
        regresar_button.place(relx=0.5, rely=0.6, anchor="center")

    pregunta_label = tk.Label(ventana, text="", font=("Arial", 22), bg="dark goldenrod", fg="black", borderwidth=5, relief="solid")
    pregunta_label.place(relx=0.5, rely=0.2, anchor="center")

    botones = [tk.Button(ventana, text="", font=("Arial", 16), width=20, height=2, bg="dark goldenrod", borderwidth=5) for _ in range(4)]
    for i, boton in enumerate(botones):
        boton.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")

    nueva_pregunta()
def segundo_secu(nombre,cajero,intentos,puntaje_final,tiempo):
    fondo=tk.Label(ventana, image=fondo_segundo_de_secundaria)#pone una imagen de fondo
    fondo.place(x=0,y=0)#pone la ubicacion de la imagen

    boton_1=tk.Frame(ventana,bg="white")
    boton_1.place(relx=0.5,rely=0.345,anchor="center")
    
    boton_1ro = tk.Button(boton_1, text="Sucesiones",command=lambda:iniciar_sucesiones(nombre, cajero, intentos, puntaje_final, tiempo),bg="beige", borderwidth=10,font=("Magic R",25,"bold"))#Activa la funcion de Sucesiones
    boton_1ro.pack()
    
    boton_2=tk.Frame(ventana,bg="white")
    boton_2.place(relx=0.5,rely=0.62,anchor="center")
    
    boton_2do = tk.Button(boton_2, text="Proporciones inversas",command=lambda:prop_inversa(nombre, cajero, intentos, puntaje_final, tiempo),bg="beige", borderwidth=10,font=("Magic R",25,"bold"))#Activa la funcion de proporciones inversas
    boton_2do.pack()
    
    boton=tk.Frame(ventana,bg="white")
    boton.place(relx=0.5,rely=0.9,anchor="center")
    
    boton_regresar = tk.Button(boton, text="Regresar",command=lambda:opciones_grado(nombre,cajero,intentos,puntaje_final,tiempo),bg="orange", borderwidth=10,font=("Magic R",12,"bold"))#te regresa a la zona de niveles
    boton_regresar.pack()

#iniciar juego de sucesiones
def iniciar_sucesiones(nombre, cajero, intentos, puntaje_final, tiempo):
    # Inicializa las variables y comienza el juego
    contador = 0
    start_time = time.time()  # Marca el tiempo de inicio del juego

    # Genera la matriz de preguntas para el juego de sucesiones
    matriz_preguntas = pregunta_1_sucesiones()

    # Inicia el generador de texto y opciones de sucesiones
    generador_de_texto_y_sucesiones(matriz_preguntas, 0, cajero, contador, intentos, puntaje_final, tiempo, start_time)

# Función para crear la matriz de preguntas y respuestas con diferentes tipos de sucesiones
def pregunta_1_sucesiones():
    matriz = []

    # Sucesión 1: c + n (pregunta por la posición 5)
    n = random.randint(1, 9)
    secuencia = [(c + n) for c in range(5)]  # Genera 5 números de la secuencia
    respuesta_correcta = secuencia[4]
    posibles_respuestas = [respuesta_correcta, random.randint(1, 20), random.randint(1, 20), random.randint(1, 20)]
    random.shuffle(posibles_respuestas)
    matriz.append([f"¿Cuál es el número en la *posición 5* de la sucesión {secuencia[:4]}?", respuesta_correcta] + posibles_respuestas)

    # Sucesión 2: (c * n) + 1 (pregunta por la posición 6)
    n = random.randint(1, 9)
    secuencia = [((c * n) + 1) for c in range(6)]  # Genera 6 números de la secuencia
    respuesta_correcta = secuencia[5]
    posibles_respuestas = [respuesta_correcta, random.randint(1, 50), random.randint(1, 50), random.randint(1, 50)]
    random.shuffle(posibles_respuestas)
    matriz.append([f"¿Cuál es el número en la *posición 6* de la sucesión {secuencia[:4]}?", respuesta_correcta] + posibles_respuestas)

    # Sucesión 3: ((c + n) * 10) / 2 (pregunta por la posición 7)
    n = random.randint(1, 9)
    secuencia = [(((c + n) * 10) / 2) for c in range(7)]  # Genera 7 números de la secuencia
    respuesta_correcta = secuencia[6]
    posibles_respuestas = [respuesta_correcta, random.randint(1, 100), random.randint(1, 100), random.randint(1, 100)]
    random.shuffle(posibles_respuestas)
    matriz.append([f"¿Cuál es el número en la *posición 7* de la sucesión {secuencia[:4]}?", respuesta_correcta] + posibles_respuestas)

    return matriz

# Función que maneja el clic en un botón
def verificar_respuesta(matriz, pregunta_numero, opcion_elegida, ventana, cajero, contador, intentos, puntaje_final, tiempo, start_time):
    respuesta_correcta = matriz[pregunta_numero][1]
    if opcion_elegida == respuesta_correcta:
        messagebox.showinfo("Correcto", "¡Respuesta correcta!")
        contador += 1
        cajero += 20  # Suma 20 al cajero por cada respuesta correcta
    else:
        messagebox.showerror("Incorrecto", "Respuesta incorrecta, inténtalo de nuevo.")

    pregunta_numero += 1
    if pregunta_numero < len(matriz):
        ventana.destroy()
        generador_de_texto_y_sucesiones(matriz, pregunta_numero, cajero, contador, intentos, puntaje_final, tiempo, start_time)
    else:
        elapsed_time = time.time() - start_time
        finalizar_juego(ventana, contador, cajero, intentos, puntaje_final, tiempo, elapsed_time)

# Función para finalizar el juego y regresar a la pantalla de segundo_secu
def finalizar_juego(ventana, contador, cajero, intentos, puntaje_final, tiempo, elapsed_time):
    ventana.destroy()  # Cerrar la ventana de preguntas
    intentos[1][0] += 1  # Actualizar intentos en la primera categoría (primer tema)
    puntaje_final[1][0].append(contador)  # Guardar el puntaje final en la primera categoría
    tiempo[1][0].append(elapsed_time)  # Guardar el tiempo final

    # Al finalizar, regresa a segundo_secu con los datos actualizados
    segundo_secu(nombre, cajero, intentos, puntaje_final, tiempo)

# Función para generar la ventana con botones
def generador_de_texto_y_sucesiones(matriz, pregunta_numero, cajero, contador, intentos, puntaje_final, tiempo, start_time):
    ventana = tk.Toplevel()  # Crea una nueva ventana sin destruir la principal
    ventana.title(f"El increible mundo de Tama")
    ancho = 1080
    alto = 720
    ancho_pantalla = ventana.winfo_screenwidth()
    altura_pantalla = ventana.winfo_screenheight()
    x = (ancho_pantalla // 2) - (ancho // 2)
    y = (altura_pantalla // 2) - (alto // 2)
    ventana.geometry(f"{ancho}x{alto}+{x}+{y}")
    ventana.resizable(False, False)

    # Asegúrate de que la imagen se mantenga referenciada
    fondo_sucesiones = tk.PhotoImage(file="fondo_segundo_de_secundaria.png")  # Asegúrate de tener esta imagen
    fondo_label = tk.Label(ventana, image=fondo_sucesiones)
    fondo_label.place(x=0, y=0)

    fondo_label.image = fondo_sucesiones  # Evita que se elimine de la memoria

    # Texto de la pregunta
    pregunta_texto = tk.Label(ventana, text=matriz[pregunta_numero][0], font=("Arial", 18), bg="aquamarine", fg="black", borderwidth=5, relief="solid")
    pregunta_texto.place(relx=0.5, rely=0.2, anchor="center")  # Coloca la pregunta en la posición deseada

    # Crear botones con las 4 opciones de respuesta
    opciones = matriz[pregunta_numero][2:6]
    botones = []
    for i, opcion in enumerate(opciones):
        boton = tk.Button(ventana, text=str(opcion), font=("Arial", 16), width=20, height=2, bg="aquamarine", borderwidth=5,
                          command=lambda opcion=opcion: verificar_respuesta(matriz, pregunta_numero, opcion, ventana, cajero, contador, intentos, puntaje_final, tiempo, start_time))
        boton.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")  # Ajusta el eje Y de los botones
        botones.append(boton)

    ventana.mainloop()
# Función que agrupa las dos funciones: pregunta_1_sucesiones y generador_de_texto_y_sucesiones
def iniciar_juego_sucesiones(nombre, cajero, contador, intentos, puntaje_final, tiempo):
    start_time = time.time()  # Marca el tiempo de inicio del juego
    matriz_preguntas = pregunta_1_sucesiones()
    generador_de_texto_y_sucesiones(matriz_preguntas, 0, cajero, contador, intentos, puntaje_final, tiempo, start_time)
# Función que maneja el juego de proporcionalidad inversa
def prop_inversa(nombre, cajero, intentos, puntaje_final, tiempo):
    # Limpiar la ventana existente
    for widget in ventana.winfo_children():
        widget.destroy()

    ventana.title("Proporcionalidad Inversa")
    ventana.geometry("1080x720")  # Tamaño de la ventana
    ventana.resizable(False, False)  # No se puede redimensionar

    # Fondo de pantalla
    fondo = tk.Label(ventana, image=fondo_segundo_de_secundaria)
    fondo.place(x=0, y=0)

    # Variables para mantener el puntaje y la pregunta actual
    intentos[1][1] += 1  # Aumentar intentos para el tema de proporcionalidad inversa
    contador = 0
    pregunta_numero = 0
    start_time = time.time()

    # Preguntas de proporcionalidad inversa
    preguntas = [
        "Si a {n1} albañiles les toma {n2} días construir un muro, ¿cuántos días les tomaría a {n3} albañiles construir el mismo muro?",
        "Si {n1} personas llenan {n2} cajas de frutas en un día, ¿cuántas cajas podrían llenar {n3} personas en el mismo tiempo?",
        "Si {n1} personas pueden pintar una casa en {n2} días, ¿en cuántos días podrían pintar la misma casa {n3} personas?",
        "{n1} máquinas producen {n2} piezas de repuesto en un día, ¿cuántas piezas producirán {n3} máquinas en el mismo tiempo?",
        "Si {n1} carros llenan {n2} tanques de gasolina en un día, ¿cuántos tanques podrán llenar {n3} carros en el mismo tiempo?",
        "{n1} estudiantes pueden preparar {n2} afiches de un evento escolar en un día, ¿cuántos afiches podrían preparar {n3} estudiantes en el mismo tiempo?",
        "Si {n1} trabajadores pueden limpiar {n2} oficinas en un día, ¿cuántas oficinas podrían limpiar {n3} trabajadores en el mismo tiempo?",
        "{n1} costureras pueden fabricar {n2} vestidos en una semana, ¿cuántos vestidos podrán fabricar {n3} costureras en el mismo tiempo?",
        "Si {n1} cocineros pueden preparar {n2} platos de comida en 2 horas, ¿cuántos platos podrían preparar {n3} cocineros en el mismo tiempo?",
        "{n1} granjeros pueden cosechar {n2} toneladas de trigo en {n2} días, ¿cuántos días les tomaría cosechar la misma cantidad a {n3} granjeros?"
    ]

    # Función que verifica la respuesta seleccionada
    def verificar_respuesta(resultado, respuesta_elegida):
        nonlocal contador, pregunta_numero, cajero
        if abs(respuesta_elegida - resultado) < 0.01:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
            cajero += 50
        else:
            messagebox.showerror("Incorrecto", f"Respuesta incorrecta. La respuesta correcta era {resultado:.2f}.")

        pregunta_numero += 1
        if pregunta_numero < 10:
            nueva_pregunta()  # Avanzar a la siguiente pregunta
        else:
            elapsed_time = time.time() - start_time
            finalizar_juego(elapsed_time)

    # Función para generar una nueva pregunta
    def nueva_pregunta():
        n1 = random.randint(2, 12)
        n2 = random.randint(2, 12)
        n3 = random.randint(4, 15)
        resultado = round((n1 * n2) // n3, 2)

        pregunta_label.config(text=preguntas[pregunta_numero].format(n1=n1, n2=n2, n3=n3))

        opciones = [resultado, random.uniform(1, 50), random.uniform(1, 50), random.uniform(1, 50)]
        random.shuffle(opciones)

        # Actualizar los botones con las opciones
        for i, opcion in enumerate(opciones):
            botones[i].config(text=f"{opcion:.2f}", command=lambda opcion=opcion: verificar_respuesta(resultado, opcion))

    # Función para finalizar el juego
    def finalizar_juego(elapsed_time):
        for widget in ventana.winfo_children():
            widget.destroy()
        puntaje_final[1][1].append(contador)
        tiempo[1][1].append(elapsed_time)
        segundo_secu(nombre, cajero, intentos, puntaje_final, tiempo)

    # Crear los elementos de la ventana
    pregunta_frame = tk.Frame(ventana, bg="black")
    pregunta_frame.place(relx=0.5, rely=0.235, anchor="center")

    pregunta_label = tk.Label(pregunta_frame, text="", font=("Arial", 13), bg="aquamarine", fg="black")
    pregunta_label.pack(padx=10, pady=10)

    botones = [tk.Button(ventana, text="", font=("Arial", 14), borderwidth=10, bg="aquamarine") for _ in range(4)]
    for i, boton in enumerate(botones):
        boton.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")

    nueva_pregunta()  # Iniciar con la primera pregunta
#tercero de secundaria
def tercero_secu(nombre,cajero,intentos,puntaje_final,tiempo):
    fondo=tk.Label(ventana, image=fondo_tercero_de_secundaria)#pone una imagen de fondo
    fondo.place(x=0,y=0)#pone la ubicacion de la imagen

    boton_1=tk.Frame(ventana,bg="white")
    boton_1.place(relx=0.5,rely=0.345,anchor="center")
    
    boton_1ro = tk.Button(boton_1, text="Pitagoras",command=lambda:pitagoras(nombre, cajero, intentos, puntaje_final, tiempo),bg="aquamarine", borderwidth=10,font=("Magic R",25,"bold"))#Te lleva a la seccion de pitagoras
    boton_1ro.pack()
    
    boton_2=tk.Frame(ventana,bg="white")
    boton_2.place(relx=0.5,rely=0.62,anchor="center")
    
    boton_2do = tk.Button(boton_2, text="Potencias y radicales",command=lambda:potencias(nombre, cajero, intentos, puntaje_final, tiempo),bg="aquamarine", borderwidth=10,font=("Magic R",25,"bold"))#te lleva al tema de potencias y radicales
    boton_2do.pack()
    
    boton=tk.Frame(ventana,bg="white")
    boton.place(relx=0.5,rely=0.9,anchor="center")
    
    boton_regresar = tk.Button(boton, text="Regresar",command=lambda:opciones_grado(nombre,cajero,intentos,puntaje_final,tiempo),bg="orange", borderwidth=10,font=("Magic R",12,"bold"))#te regresa a los niveles de examenes
    boton_regresar.pack()

def potencias(nombre, cajero, intentos, puntaje_final, tiempo):
    # Limpiar la ventana existente
    for widget in ventana.winfo_children():
        widget.destroy()

    # Fondo de pantalla
    fondo = tk.Label(ventana, image=fondo_tercero_de_secundaria)
    fondo.place(x=0, y=0)

    # Variables para mantener el puntaje y la pregunta actual
    intentos[2][1] += 1  # Aumentar intentos para el tema de potencias
    contador = 0
    pregunta_numero = 0
    total_preguntas = 5  # Número total de preguntas
    start_time = time.time()

    # Función para verificar la respuesta y avanzar a la siguiente pregunta
    def verificar_respuesta(resultado_real, respuesta_elegida):
        nonlocal pregunta_numero, cajero, contador
        if abs(respuesta_elegida - resultado_real) < 0.01:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
            cajero += 20
        else:
            messagebox.showerror("Incorrecto", f"Incorrecto. La respuesta correcta es {resultado_real}.")

        pregunta_numero += 1
        if pregunta_numero < total_preguntas:
            nueva_pregunta()
        else:
            elapsed_time = time.time() - start_time
            finalizar_juego(elapsed_time)

    # Función para generar una nueva pregunta
    def nueva_pregunta():
        if pregunta_numero == 0:
            # Ejercicio 1: Suma de exponentes
            exp1 = random.randint(1, 10)
            exp2 = random.randint(1, 10)
            resultado_real = exp1 + exp2
            pregunta.config(text=f"¿Cuánto es el exponente de la siguiente expresión simplificada?\n x^{exp1} * x^{exp2}")
        elif pregunta_numero == 1:
            # Ejercicio 2: Potencia de potencias
            pot1 = random.randint(1, 10)
            pot2 = random.randint(1, 10)
            resultado_real = pot1 * pot2
            pregunta.config(text=f"¿Cuánto es el exponente de la siguiente expresión simplificada?\n (x^{pot1})^{pot2}")
        else:
            # Ejercicio 3: División de potencias
            m = random.randint(1, 10)
            n = random.randint(1, 10)
            resultado_real = m - n
            pregunta.config(text=f"¿Cuál es el valor del exponente final para la siguiente expresión?\n x^{m} / x^{n}")

        opciones = [resultado_real, random.randint(1, 20), random.randint(1, 20), random.randint(1, 20)]
        random.shuffle(opciones)

        # Actualizar los botones con las opciones
        for i, opcion in enumerate(opciones):
            botones[i].config(text=f"{opcion}", command=lambda opcion=opcion: verificar_respuesta(resultado_real, opcion))

    # Función para finalizar el juego
    def finalizar_juego(elapsed_time):
        for widget in ventana.winfo_children():
            widget.destroy()
        ejercicio_raices(nombre, cajero, intentos, puntaje_final, tiempo,contador)

    # Crear los elementos de la ventana
    pregunta_frame = tk.Frame(ventana, bg="black")
    pregunta_frame.place(relx=0.5, rely=0.235, anchor="center")

    pregunta = tk.Label(pregunta_frame, text="", font=("Arial", 22), bg="aquamarine", fg="black")
    pregunta.pack(padx=10, pady=10)

    botones = [tk.Button(ventana, text="", font=("Arial", 14), borderwidth=10, bg="aquamarine") for _ in range(4)]
    for i, boton in enumerate(botones):
        boton.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")

    nueva_pregunta()  # Iniciar con la primera pregunta

# Función que maneja los ejercicios de raíces
def ejercicio_raices(nombre, cajero, intentos, puntaje_final, tiempo,contador):
    # Limpiar la ventana existente
    for widget in ventana.winfo_children():
        widget.destroy()

    # Fondo de pantalla
    fondo = tk.Label(ventana, image=fondo_tercero_de_secundaria)
    fondo.place(x=0, y=0)

    # Variables para mantener el puntaje y la pregunta actual
    contador = 0
    pregunta_numero = 0
    total_preguntas = 5  # Número total de preguntas
    start_time = time.time()

    # Función para verificar la respuesta y avanzar a la siguiente pregunta
    def verificar_respuesta(resultado_real, respuesta_elegida):
        nonlocal pregunta_numero, cajero, contador
        if respuesta_elegida == resultado_real:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
            cajero += 20
        else:
            messagebox.showerror("Incorrecto", f"Incorrecto. La respuesta correcta es {resultado_real}.")

        pregunta_numero += 1
        if pregunta_numero < total_preguntas:
            nueva_pregunta()
        else:
            elapsed_time = time.time() - start_time
            finalizar_juego(elapsed_time)

    # Función para generar una nueva pregunta
    def nueva_pregunta():
        if pregunta_numero == 0:
            # Ejercicio 1: Raíz simple
            n = random.randint(2, 5)
            a = random.randint(2, 10)
            resultado_real = f"√({a})"
            pregunta.config(text=f"¿Cuál es el equivalente de la siguiente expresión como raíz?\n {a}^(1/{n})")
        elif pregunta_numero == 1:
            # Ejercicio 2: Potencia fraccionaria
            m = random.randint(2, 5)
            n = random.randint(2, 5)
            a = random.randint(2, 10)
            resultado_real = f"√({a**m})"
            pregunta.config(text=f"¿Cuál es el equivalente de la siguiente expresión como raíz?\n {a}^({m}/{n})")
        else:
            # Ejercicio 3: Raíz de fracciones
            n = random.randint(2, 5)
            a = random.randint(2, 10)
            b = random.randint(2, 10)
            resultado_real = f"√({a})/√({b})"
            pregunta.config(text=f"¿Cuál es el equivalente de la siguiente expresión como raíz?\n ({a}/{b})^(1/{n})")

        opciones = [resultado_real, f"√({random.randint(1, 15)})", f"√({random.randint(1, 15)})", f"√({random.randint(1, 15)})"]
        random.shuffle(opciones)

        # Actualizar los botones con las opciones
        for i, opcion in enumerate(opciones):
            botones[i].config(text=f"{opcion}", command=lambda opcion=opcion: verificar_respuesta(resultado_real, opcion))

    # Función para finalizar el juego
    def finalizar_juego(elapsed_time):
        for widget in ventana.winfo_children():
            widget.destroy()
        puntaje_final[2][1].append(contador)
        tiempo[2][1].append(elapsed_time)
        tercero_secu(nombre, cajero, intentos, puntaje_final, tiempo)

    # Crear los elementos de la ventana
    pregunta_frame = tk.Frame(ventana, bg="black")
    pregunta_frame.place(relx=0.5, rely=0.235, anchor="center")

    pregunta = tk.Label(pregunta_frame, text="", font=("Arial", 22), bg="aquamarine", fg="black")
    pregunta.pack(padx=10, pady=10)

    botones = [tk.Button(ventana, text="", font=("Arial", 14), borderwidth=10, bg="aquamarine") for _ in range(4)]
    for i, boton in enumerate(botones):
        boton.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")

    nueva_pregunta()  # Iniciar con la primera pregunta

# Función principal para iniciar potencias y luego raíces
def potencias_radicales(nombre, cajero, intentos, puntaje_final, tiempo):
    potencias(nombre, cajero, intentos, puntaje_final, tiempo)
# Ejercicios de Pitagoras
def pitagoras(nombre, cajero, intentos, puntaje_final, tiempo):
    # Limpiar la ventana existente
    for widget in ventana.winfo_children():
        widget.destroy()

    # Fondo de pantalla
    fondo = tk.Label(ventana, image=fondo_tercero_de_secundaria)  # Fondo de tercero de secundaria
    fondo.place(x=0, y=0)

    # Variables para mantener el puntaje y la pregunta actual
    intentos[2][0] += 1  # Aumentar los intentos para el tema de Pitágoras
    contador = 0
    pregunta_numero = 0
    start_time = time.time()

    # Función que verifica la respuesta seleccionada
    def verificar_respuesta(a, b, resultado_correcto, respuesta_elegida):
        nonlocal contador, pregunta_numero, cajero
        if abs(respuesta_elegida - resultado_correcto) < 0.01:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
            cajero += 20
        else:
            messagebox.showerror("Incorrecto", f"Respuesta incorrecta. La respuesta correcta era {resultado_correcto:.2f}.")

        pregunta_numero += 1
        if pregunta_numero < 5:
            nueva_pregunta()
        else:
            elapsed_time = time.time() - start_time
            finalizar_juego(elapsed_time)

    # Función para generar una nueva pregunta
    def nueva_pregunta():
        a = random.randint(3, 10) * (pregunta_numero + 1)
        b = random.randint(4, 10) * (pregunta_numero + 1)
        resultado_correcto = round(math.sqrt(a ** 2 + b ** 2), 2)

        pregunta.config(text=f"El siguiente triángulo rectángulo tiene lados: {a} y {b}. ¿Cuánto mide su hipotenusa?")

        opciones = [resultado_correcto, random.uniform(1, 50), random.uniform(1, 50), random.uniform(1, 50)]
        random.shuffle(opciones)

        # Actualizar los botones con las opciones
        for i, opcion in enumerate(opciones):
            botones[i].config(text=f"{opcion:.2f}", command=lambda opt=opcion: verificar_respuesta(a, b, resultado_correcto, opt))

    # Función para finalizar el juego
    def finalizar_juego(elapsed_time):
        for widget in ventana.winfo_children():
            widget.destroy()
        puntaje_final[2][0].append(contador)
        tiempo[2][0].append(elapsed_time)
        tercero_secu(nombre, cajero, intentos, puntaje_final, tiempo)  # Regresar a la pantalla de tercero de secundaria

    # Crear los elementos de la ventana
    pregunta_frame = tk.Frame(ventana, bg="black")
    pregunta_frame.place(relx=0.5, rely=0.235, anchor="center")

    pregunta = tk.Label(pregunta_frame, text="", font=("Arial", 22), bg="aquamarine", fg="black")
    pregunta.pack(padx=10, pady=10)

    botones = [tk.Button(ventana, text="", font=("Arial", 14), borderwidth=10, bg="aquamarine") for _ in range(4)]
    for i, boton in enumerate(botones):
        boton.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")

    nueva_pregunta()

# Sección de exámenes
def examen_secu(nombre, cajero, intentos, puntaje_final, tiempo):
    fondo = tk.Label(ventana, image=fondo_examenes)  # Set the background
    fondo.place(x=0, y=0)  # Place it to cover the entire window

    # Examen de primero de secundaria
    boton_1 = tk.Frame(ventana, bg="white")
    boton_1.place(relx=0.5, rely=0.265, anchor="center")  # Adjust the position and make sure it’s centered

    boton_1ro = tk.Button(boton_1, text="Examen primero de secundaria", command=lambda: examen_final_primero(nombre, cajero, intentos, puntaje_final, tiempo), bg="dark goldenrod", borderwidth=10, font=("Magic R", 25, "bold"))
    boton_1ro.pack()

    # Examen de segundo de secundaria
    boton_2 = tk.Frame(ventana, bg="white")
    boton_2.place(relx=0.5, rely=0.495, anchor="center")

    boton_2do = tk.Button(boton_2, text="Examen Segundo de secundaria", command=lambda: examen_final_segundo(nombre, cajero, intentos, puntaje_final, tiempo), bg="dark goldenrod", borderwidth=10, font=("Magic R", 25, "bold"))
    boton_2do.pack()

    # Examen de tercero de secundaria
    boton_3 = tk.Frame(ventana, bg="white")
    boton_3.place(relx=0.5, rely=0.735, anchor="center")

    boton_3ro = tk.Button(boton_3, text="Examen Tercero de secundaria", command=lambda: examen_final_tercero(nombre, cajero, intentos, puntaje_final, tiempo), bg="dark goldenrod", borderwidth=10, font=("Magic R", 25, "bold"))
    boton_3ro.pack()

    # Boton de regresar
    boton = tk.Frame(ventana, bg="white")
    boton.place(relx=0.5, rely=0.9, anchor="center")

    boton_regresar = tk.Button(boton, text="Regresar", command=lambda: opciones_grado(nombre, cajero, intentos, puntaje_final, tiempo), bg="orange", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_regresar.pack()
# Función que maneja el examen final de tercero de secundaria
def examen_final_tercero(nombre, cajero, intentos, puntaje_final, tiempo):
    ventana.title("Examen Final de Tercero de Secundaria")
    ancho = 1080
    alto = 720
    ancho_pantalla = ventana.winfo_screenwidth()
    altura_pantalla = ventana.winfo_screenheight()
    x = (ancho_pantalla // 2) - (ancho // 2)
    y = (altura_pantalla // 2) - (alto // 2)
    ventana.geometry(f"{ancho}x{alto}+{x}+{y}")
    ventana.resizable(False, False)

    # Fondo de pantalla
    fondo_examenes = tk.PhotoImage(file="fondo_examenes.png")
    fondo = tk.Label(ventana, image=fondo_examenes)
    fondo.place(x=0, y=0)
    
    # Mantener la referencia a la imagen
    fondo.image = fondo_examenes

    contador = 0
    pregunta_numero = 0
    total_preguntas = 10  # Total de preguntas
    intentos[3][2] += 1  # Aumentar intentos en el examen de tercero de secundaria
    start_time = time.time()

    # Función para avanzar a la siguiente pregunta
    def verificar_respuesta(resultado_real, respuesta_elegida):
        nonlocal pregunta_numero, contador, cajero
        if abs(respuesta_elegida - resultado_real) < 0.01:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
            cajero += 50
        else:
            messagebox.showerror("Incorrecto", f"Incorrecto. La respuesta correcta era {resultado_real}.")

        pregunta_numero += 1
        if pregunta_numero < total_preguntas:
            nueva_pregunta()
        else:
            mostrar_resultado_final(contador)

    # Función para generar una nueva pregunta
    def nueva_pregunta():
        if pregunta_numero < 4:
            # Sección 1: Teorema de Pitágoras
            a = random.randint(3, 12)
            b = random.randint(3, 12)
            resultado_real = round(math.sqrt(a ** 2 + b ** 2), 2)
            pregunta_label.config(text=f"Triángulo rectángulo con catetos {a} y {b}. ¿Cuál es la hipotenusa?")
        elif pregunta_numero < 7:
            # Sección 2: Potencias
            exp1 = random.randint(1, 10)
            exp2 = random.randint(1, 10)
            resultado_real = exp1 + exp2
            pregunta_label.config(text=f"¿Cuánto es x^{exp1} * x^{exp2}?")
        else:
            # Sección 3: Radicales
            n = random.randint(2, 5)
            a = random.randint(2, 10)
            resultado_real = round(a ** (1/n), 2)
            pregunta_label.config(text=f"¿Cuál es el equivalente de la expresión {a}^(1/{n})?")

        opciones = [resultado_real, random.uniform(1, 20), random.uniform(1, 20), random.uniform(1, 20)]
        random.shuffle(opciones)

        # Actualizar los botones con las opciones
        for i, opcion in enumerate(opciones):
            botones[i].config(text=f"{opcion:.2f}", command=lambda opcion=opcion: verificar_respuesta(resultado_real, opcion))

    # Función para mostrar el resultado final en la misma ventana
    def mostrar_resultado_final(contador):
        # Limpiar la ventana eliminando widgets anteriores
        for widget in ventana.winfo_children():
            widget.destroy()

        # Fondo de pantalla para resultado
        fondo_examenes = tk.PhotoImage(file="fondo_examenes.png")
        fondo = tk.Label(ventana, image=fondo_examenes)
        fondo.place(x=0, y=0)
        fondo.image = fondo_examenes  # Referencia para evitar que sea eliminado

        # Mostrar el puntaje final
        resultado_label = tk.Label(ventana, text=f"¡Examen Final Completado!\nPuntaje: {contador} respuestas correctas", font=("Arial", 22), bg="dark goldenrod", fg="black")
        resultado_label.place(relx=0.5, rely=0.3, anchor="center")

        # Guardar el puntaje y tiempo
        puntaje_final[3][2].append(contador)
        tiempo[3][2].append(time.time() - start_time)

        # Botón para regresar a exámenes
        regresar_button = tk.Button(ventana, text="Regresar a Exámenes", font=("Arial", 16), bg="dark goldenrod", fg="black", command=lambda: examen_secu(nombre, cajero, intentos, puntaje_final, tiempo))
        regresar_button.place(relx=0.5, rely=0.6, anchor="center")

    # Crear los elementos de la ventana
    pregunta_label = tk.Label(ventana, text="", font=("Arial", 22), bg="dark goldenrod", fg="black", borderwidth=5, relief="solid")
    pregunta_label.place(relx=0.5, rely=0.2, anchor="center")

    botones = []
    for i in range(4):
        boton = tk.Button(ventana, text="", font=("Arial", 16), width=20, height=2, bg="dark goldenrod", borderwidth=5)
        boton.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")
        botones.append(boton)

    nueva_pregunta()  # Iniciar con la primera pregunta
    ventana.mainloop()
# Función que maneja el examen final de segundo de secundaria
def examen_final_segundo(nombre, cajero, intentos, puntaje_final, tiempo):
    ventana.title("Examen Final de Segundo de Secundaria")
    ancho = 1080
    alto = 720
    ancho_pantalla = ventana.winfo_screenwidth()
    altura_pantalla = ventana.winfo_screenheight()
    x = (ancho_pantalla // 2) - (ancho // 2)
    y = (altura_pantalla // 2) - (alto // 2)
    ventana.geometry(f"{ancho}x{alto}+{x}+{y}")
    ventana.resizable(False, False)

    # Fondo de pantalla
    fondo_examenes = tk.PhotoImage(file="fondo_examenes.png")
    fondo = tk.Label(ventana, image=fondo_examenes)
    fondo.place(x=0, y=0)
    
    # Mantener la referencia a la imagen
    fondo.image = fondo_examenes

    contador = 0
    pregunta_numero = 0
    total_preguntas = 10  # Total de preguntas (5 de proporcionalidad inversa y 5 de sucesiones)
    intentos[3][1] += 1  # Aumentar intentos en el examen de segundo de secundaria
    start_time = time.time()

    # Preguntas de proporcionalidad inversa
    preguntas_inversa = [
        "Si {n1} albañiles les toma {n2} días construir un muro, ¿cuántos días les tomaría a {n3} albañiles construir el mismo muro?",
        "Si {n1} personas llenan {n2} cajas de frutas en un día, ¿cuántas cajas podrían llenar {n3} personas en el mismo tiempo?",
        "Si {n1} personas pueden pintar una casa en {n2} días, ¿en cuántos días podrían pintar la misma casa {n3} personas?",
        "{n1} máquinas producen {n2} piezas de repuesto en un día, ¿cuántas piezas producirán {n3} máquinas en el mismo tiempo?",
        "Si {n1} carros llenan {n2} tanques de gasolina en un día, ¿cuántos tanques podrán llenar {n3} carros en el mismo tiempo?"
    ]

    # Función para verificar la respuesta y avanzar a la siguiente pregunta
    def verificar_respuesta(resultado_real, respuesta_elegida):
        nonlocal pregunta_numero, contador, cajero
        if abs(respuesta_elegida - resultado_real) < 0.01:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
        else:
            messagebox.showerror("Incorrecto", f"Incorrecto. La respuesta correcta era {resultado_real}.")
        
        pregunta_numero += 1
        if pregunta_numero < total_preguntas:
            nueva_pregunta()
        else:
            mostrar_resultado_final(contador)

    # Función para generar una nueva pregunta
    def nueva_pregunta():
        if pregunta_numero < 5:
            # Sección 1: Proporcionalidad Inversa
            n1 = random.randint(2, 12)
            n2 = random.randint(2, 12)
            n3 = random.randint(4, 15)
            resultado_real = round((n1 * n2) // n3, 2)
            pregunta_label.config(text=preguntas_inversa[pregunta_numero].format(n1=n1, n2=n2, n3=n3))
        else:
            # Sección 2: Sucesiones
            n = random.randint(1, 9)
            lista = [(c + n) for c in range(5)]
            resultado_real = lista[-1]
            pregunta_label.config(text=f"Sucesión: {' '.join(map(str, lista[:-1]))} _")

        # Generar opciones aleatorias de respuestas
        opciones = [resultado_real, random.uniform(1, 20), random.uniform(1, 20), random.uniform(1, 20)]
        random.shuffle(opciones)

        # Actualizar los botones con las opciones
        for i, opcion in enumerate(opciones):
            botones[i].config(text=f"{opcion:.2f}" if isinstance(opcion, float) else str(opcion),
                              command=lambda opcion=opcion: verificar_respuesta(resultado_real, opcion))

    # Función para mostrar el resultado final
    def mostrar_resultado_final(contador):
        # Limpiar la ventana eliminando widgets anteriores
        pregunta_label.config(text=f"¡Examen Final Completado!\nPuntaje: {contador} respuestas correctas")

        # Ocultar todos los botones de opción
        for boton in botones:
            boton.place_forget()

        # Botón para regresar a exámenes
        regresar_button = tk.Button(ventana, text="Regresar a Exámenes", font=("Arial", 16), width=20, height=2, bg="dark goldenrod", command=lambda: examen_secu(nombre, cajero, intentos, puntaje_final, tiempo))
        regresar_button.place(relx=0.5, rely=0.7, anchor="center")

    # Crear los elementos de la ventana para preguntas y opciones
    pregunta_label = tk.Label(ventana, text="", font=("Arial", 14), bg="dark goldenrod", fg="black", borderwidth=5, relief="solid")
    pregunta_label.place(relx=0.5, rely=0.2, anchor="center")

    botones = []
    for i in range(4):
        boton = tk.Button(ventana, text="", font=("Arial", 16), width=20, height=2, bg="dark goldenrod", borderwidth=5)
        boton.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")
        botones.append(boton)

    nueva_pregunta()  # Iniciar con la primera pregunta
    ventana.mainloop()
# Función que maneja el examen final de primero de secundaria
def examen_final_primero(nombre, cajero, intentos, puntaje_final, tiempo):
    ventana.title("Examen Final de Primero de Secundaria")
    ancho = 1080
    alto = 720
    ancho_pantalla = ventana.winfo_screenwidth()
    altura_pantalla = ventana.winfo_screenheight()
    x = (ancho_pantalla // 2) - (ancho // 2)
    y = (altura_pantalla // 2) - (alto // 2)
    ventana.geometry(f"{ancho}x{alto}+{x}+{y}")
    ventana.resizable(False, False)

    # Fondo de pantalla
    fondo_examenes = tk.PhotoImage(file="fondo_examenes.png")
    fondo = tk.Label(ventana, image=fondo_examenes)
    fondo.place(x=0, y=0)
    
    # Mantener la referencia a la imagen
    fondo.image = fondo_examenes

    contador = 0
    pregunta_numero = 0
    total_preguntas = 10  # Total de preguntas (3 de fracciones, 3 de porcentajes, 4 de potencias)
    start_time = time.time()
    intentos[3][0] += 1  # Aumentar intentos en el examen de primero de secundaria

    # Función para avanzar a la siguiente pregunta
    def verificar_respuesta(resultado_real, respuesta_elegida):
        nonlocal pregunta_numero, contador, cajero
        if abs(respuesta_elegida - resultado_real) < 0.01:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
            contador += 1
            cajero += 20
        else:
            messagebox.showerror("Incorrecto", f"Incorrecto. La respuesta correcta era {resultado_real}.")
        pregunta_numero += 1
        if pregunta_numero < total_preguntas:
            nueva_pregunta()
        else:
            mostrar_resultado_final(contador)

    # Función para generar una nueva pregunta
    def nueva_pregunta():
        if pregunta_numero < 3:
            # Sección 1: Fracciones
            num1, den1 = random.randint(1, 10), random.randint(1, 10)
            num2, den2 = random.randint(1, 10), random.randint(1, 10)
            fraccion1 = fractions.Fraction(num1, den1)
            fraccion2 = fractions.Fraction(num2, den2)
            operador = random.choice(['+', '-', '*', '/'])
            if operador == '+':
                resultado_real = fraccion1 + fraccion2
            elif operador == '-':
                resultado_real = fraccion1 - fraccion2
            elif operador == '*':
                resultado_real = fraccion1 * fraccion2
            else:
                resultado_real = fraccion1 / fraccion2
            pregunta_label.config(text=f"¿Cuánto es {fraccion1} {operador} {fraccion2}?")
        elif pregunta_numero < 6:
            # Sección 2: Porcentajes
            total = random.randint(50, 500)
            porcentaje = random.randint(1, 100)
            resultado_real = round(total * (porcentaje / 100), 2)
            pregunta_label.config(text=f"¿Cuál es el {porcentaje}% de {total}?")
        else:
            # Sección 3: Potencias
            base = random.randint(1, 10)
            exponente = random.randint(2, 3)
            resultado_real = base ** exponente
            pregunta_label.config(text=f"¿Cuánto es {base} elevado a la {exponente}?")

        # Generar opciones aleatorias de respuesta
        opciones = [resultado_real, random.uniform(1, 100), random.uniform(1, 100), random.uniform(1, 100)]
        random.shuffle(opciones)

        # Actualizar los botones con las opciones
        for i, opcion in enumerate(opciones):
            botones[i].config(text=f"{opcion:.2f}" if isinstance(opcion, float) else str(opcion),
                              command=lambda opcion=opcion: verificar_respuesta(resultado_real, opcion))

    # Función para mostrar el resultado final en la misma ventana
    def mostrar_resultado_final(contador):
        # Limpiar la ventana eliminando widgets anteriores
        for widget in ventana.winfo_children():
            widget.destroy()

        # Fondo de pantalla para resultado
        fondo_examenes = tk.PhotoImage(file="fondo_examenes.png")
        fondo = tk.Label(ventana, image=fondo_examenes)
        fondo.place(x=0, y=0)
        fondo.image = fondo_examenes  # Referencia para evitar que sea eliminado

        # Mostrar el puntaje final
        resultado_label = tk.Label(ventana, text=f"¡Examen Final Completado!\nPuntaje: {contador} respuestas correctas", font=("Arial", 22), bg="dark goldenrod", fg="black")
        resultado_label.place(relx=0.5, rely=0.3, anchor="center")

        # Guardar el puntaje y tiempo
        puntaje_final[3][0].append(contador)
        tiempo[3][0].append(time.time() - start_time)

        # Botón para regresar a exámenes
        regresar_button = tk.Button(ventana, text="Regresar a Exámenes", font=("Arial", 16), bg="dark goldenrod", fg="black", command=lambda: examen_secu(nombre, cajero, intentos, puntaje_final, tiempo))
        regresar_button.place(relx=0.5, rely=0.6, anchor="center")

    # Crear los elementos de la ventana
    pregunta_label = tk.Label(ventana, text="", font=("Arial", 22), bg="dark goldenrod", fg="black", borderwidth=5, relief="solid")
    pregunta_label.place(relx=0.5, rely=0.2, anchor="center")

    botones = []
    for i in range(4):
        boton = tk.Button(ventana, text="", font=("Arial", 16), width=20, height=2, bg="dark goldenrod", borderwidth=5)
        boton.place(relx=0.5, rely=0.35 + i * 0.15, anchor="center")
        botones.append(boton)

    nueva_pregunta()  # Iniciar con la primera pregunta
    ventana.mainloop()
# Función que maneja los resultados de los exámenes
def resultados(nombre, cajero, intentos, puntaje_final, tiempo):
    for widget in ventana.winfo_children():  # Elimina todas las ventanas existentes
        widget.destroy()

    # Fondo de pantalla (imagen de fondo)
    fondo = tk.Label(ventana, image=fondo_resultados)
    fondo.place(x=0, y=0)  # Pone la ubicación de la imagen

    # Botón de Resultados de Primero de Secundaria
    boton_1ro = tk.Button(ventana, text="Resultados de Primero de Secundaria",
                          command=lambda: graf_1(nombre, intentos, puntaje_final, tiempo),
                          bg="violet", borderwidth=10, font=("Magic R", 11, "bold"))
    boton_1ro.place(relx=0.2, rely=0.235, anchor="center")

    # Botón de Resultados de Segundo de Secundaria
    boton_2do = tk.Button(ventana, text="Resultados Segundo de Secundaria",
                          command=lambda: graf_2(nombre, intentos, puntaje_final, tiempo),
                          bg="violet", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_2do.place(relx=0.2, rely=0.365, anchor="center")

    # Botón de Resultados de Tercero de Secundaria
    boton_3ro = tk.Button(ventana, text="Resultados Tercero de Secundaria",
                          command=lambda: graf_3(nombre, intentos, puntaje_final, tiempo),
                          bg="violet", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_3ro.place(relx=0.2, rely=0.495, anchor="center")

    # Botón para Resultados de Exámenes
    boton_examen = tk.Button(ventana, text="Resultados Exámenes",
                             command=lambda: graf_ex(nombre, intentos, puntaje_final, tiempo),
                             bg="black", fg="violet", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_examen.place(relx=0.2, rely=0.625, anchor="center")

    # Botón para Certificado
    boton_certificado = tk.Button(ventana, text="Certificado",
                                  command=lambda: certificado(nombre, cajero),
                                  bg="black", fg="yellow", borderwidth=10, font=("Magic R", 22, "bold"))
    boton_certificado.place(relx=0.8, rely=0.75, anchor="center")

    # Botón para regresar a la pantalla anterior
    boton_regresar = tk.Button(ventana, text="Regresar",
                               command=lambda: opciones_grado(nombre, cajero, intentos, puntaje_final, tiempo),
                               bg="orange", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_regresar.place(relx=0.5, rely=0.9, anchor="center")


# Función para verificar si el usuario tiene suficientes Tama Dólares para el certificado
def certificado(nombre, cajero):
    cantidad_requerida = 1000  # Tama Dólares requeridos

    if cajero >= cantidad_requerida:
        generar_certificado(nombre)  # Llamar a la función si tiene suficiente dinero
    else:
        falta = cantidad_requerida - cajero
        messagebox.showerror("Error", f"Tienes {cajero} Tama Dólares. Te faltan {falta} Tama Dólares para generar el certificado.\nPara conseguir mas Tama dolares completa ejercicios de actividades o del examen que valen X2")


# Función que se llama si el usuario tiene suficientes Tama Dólares
def generar_certificado(nombre_usuario):
    # Cargar la plantilla del certificado
    imagen_certificado = Image.open('certificadoTama.png')
    
    # Crear un objeto para dibujar sobre la imagen
    draw = ImageDraw.Draw(imagen_certificado)

    # Definir la fuente (asegúrate de que esta fuente esté disponible)
    try:
        fuente = ImageFont.truetype("arial.ttf", 60)  # Cambia el tamaño a 60
    except IOError:
        fuente = ImageFont.load_default()  # Usar la fuente por defecto si no encuentra la especificada

    # Definir la posición personalizada del texto
    ancho, alto = imagen_certificado.size
    posicion_texto = (ancho // 2 - len(nombre_usuario) * 15, alto // 2 - 100)

    # Dibujar el nombre del usuario sobre el certificado
    draw.text(posicion_texto, nombre_usuario, font=fuente, fill="black")

    # Guardar el certificado personalizado
    nombre_archivo = f"certificado_{nombre_usuario}.png"
    imagen_certificado.save(nombre_archivo)

    print(f"Certificado generado: {nombre_archivo}")
def opciones_grado(nombre, cajero, intentos, puntaje_final, tiempo):
    for widget in ventana.winfo_children():  # Elimina todas las ventanas existentes
        widget.destroy()
    fondo = tk.Label(ventana, image=fondo_opciones_grados)  # Pone una imagen de fondo
    fondo.place(x=0, y=0)  # Pone la ubicación de la imagen

    # Nivel 1 - Primero de Secundaria
    boton_1 = tk.Frame(ventana, bg="white")
    boton_1.place(relx=0.1, rely=0.315, anchor="center")
    boton_1ro = tk.Button(boton_1, text="Nivel 1\n(Primero de Secundaria)", command=lambda: primero_secu(nombre, cajero, intentos, puntaje_final, tiempo), bg="green", borderwidth=10, font=("Magic R", 11, "bold"))
    boton_1ro.pack()

    # Nivel 2 - Segundo de Secundaria
    boton_2 = tk.Frame(ventana, bg="white")
    boton_2.place(relx=0.355, rely=0.315, anchor="center")
    boton_2do = tk.Button(boton_2, text="Nivel 2\n(Segundo de Secundaria)", command=lambda: segundo_secu(nombre, cajero, intentos, puntaje_final, tiempo), bg="yellow", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_2do.pack()

    # Nivel 3 - Tercero de Secundaria
    boton_3 = tk.Frame(ventana, bg="white")
    boton_3.place(relx=0.63, rely=0.315, anchor="center")
    boton_3ro = tk.Button(boton_3, text="Nivel 3\n(Tercero de Secundaria)", command=lambda: tercero_secu(nombre, cajero, intentos, puntaje_final, tiempo), bg="red", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_3ro.pack()

    # Examenes
    boton_ex = tk.Frame(ventana, bg="white")
    boton_ex.place(relx=0.9, rely=0.315, anchor="center")
    boton_examen = tk.Button(boton_ex, text="Nivel 4\n(Examenes)", command=lambda: examen_secu(nombre, cajero, intentos, puntaje_final, tiempo), bg="black", fg="white", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_examen.pack()

    # Botón de Inicio
    boton = tk.Frame(ventana, bg="white")
    boton.place(relx=0.42, rely=0.9, anchor="center")
    boton_regresar = tk.Button(boton, text="Inicio", command=lambda: inicio(fondo_inicio), bg="orange", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_regresar.pack()

    # Botón de Resultados
#     boton2 = tk.Frame(ventana, bg="white")
#     boton2.place(relx=0.58, rely=0.9, anchor="center")
#     boton_resultados = tk.Button(boton2, text="Resultados", command=lambda: resultados(nombre, cajero, intentos, puntaje_final, tiempo), bg="beige", borderwidth=10, font=("Magic R", 12, "bold"))
#     boton_resultados.pack()
#     boton2 = tk.Frame(ventana, bg="white")
    boton2 = tk.Frame(ventana, bg="white")
    boton2.place(relx=0.58, rely=0.9, anchor="center")
    boton_resultados = tk.Button(boton2, text="Resultados", command=lambda:certificado(nombre, cajero), bg="beige", borderwidth=10, font=("Magic R", 12, "bold"))
    boton_resultados.pack()
    boton2 = tk.Frame(ventana, bg="white")
def nombre():
    nombre_usuario = simpledialog.askstring("Input", "Ingresa tu nombre:")
    if nombre_usuario:
        cajero = 0
        intentos = [[0, 0, 0], [0, 0], [0, 0], [0, 0, 0]]  # Intentos en [[temas de primero], [temas de segundo], [temas de tercero], [examenes]]
        puntaje_final = [[[], [], []], [[], []], [[], []], [[], [], []]]  # Puntaje en [[temas de primero], [temas de segundo], [temas de tercero], [examenes]]
        tiempo = [[[], [], []], [[], []], [[], []], [[], [], []]]  # Tiempo en cada tema [[temas de primero], [temas de segundo], [temas de tercero], [examenes]]
        opciones_grado(nombre_usuario, cajero, intentos, puntaje_final, tiempo)
    else:
        print("")
import tkinter as tk
from tkinter import simpledialog, messagebox
import random

def inicio(fondo_inicio):
    for widget in ventana.winfo_children():  # Elimina todas las ventanas existentes
        widget.destroy()

    fondo = tk.Label(ventana, image=fondo_inicio)  # Pone una imagen de fondo
    fondo.place(x=0, y=0)  # Pone la ubicación de la imagen

    boton = tk.Frame(ventana, bg="white")
    boton.place(relx=0.5125, rely=0.566, anchor="center")

    boton_inicio = tk.Button(boton, text="Iniciar", command=nombre, bg="gray", borderwidth=10, font=("Magic R", 40, "bold"))
    boton_inicio.pack()

# Función para ingresar nombre
def nombre():
    nombre_usuario = simpledialog.askstring("Input", "Ingresa tu nombre:")
    if nombre_usuario:
        cajero = 0
        intentos = [[0, 0, 0], [0, 0], [0, 0], [0, 0, 0]]  # Intentos en [[temas de primero], [temas de segundo], [temas de tercero], [examenes]]
        puntaje_final = [[[], [], []], [[], []], [[], []], [[], [], []]]  # Puntaje en [[temas de primero], [temas de segundo], [temas de tercero], [examenes]]
        tiempo = [[[], [], []], [[], []], [[], []], [[], [], []]]  # Tiempo en [[temas de primero], [temas de segundo], [temas de tercero], [examenes]]
        opciones_grado(nombre_usuario, cajero, intentos, puntaje_final, tiempo)
    else:
        print("No se ingresó un nombre.")

# Ventana principal
ventana = tk.Tk()
ventana.title("El increíble mundo de Tama")
ancho = 1080
alto = 720
ancho_pantalla = ventana.winfo_screenwidth()
altura_pantalla = ventana.winfo_screenheight()
x = (ancho_pantalla // 2) - (ancho // 2)
y = (altura_pantalla // 2) - (alto // 2)
ventana.geometry(f"{ancho}x{alto}+{x}+{y}")
ventana.resizable(False, False)

# Cargar imágenes
try:
    fondo_inicio = tk.PhotoImage(file="fondo_inicio.png")
    fondo_opciones_grados = tk.PhotoImage(file="fondo_opciones_grados.png")
    fondo_primero_de_secundaria = tk.PhotoImage(file="fondo_primero_de_secundaria.png")
    fondo_segundo_de_secundaria = tk.PhotoImage(file="fondo_segundo_de_secundaria.png")
    fondo_tercero_de_secundaria = tk.PhotoImage(file="fondo_tercero_de_secundaria.png")
    fondo_examenes = tk.PhotoImage(file="fondo_examenes.png")
    fondo_resultados = tk.PhotoImage(file="fondo_resultados.png")
except tk.TclError as e:
    print(f"Error cargando imágenes: {str(e)}")

# Iniciar la aplicación
inicio(fondo_inicio)
ventana.mainloop()
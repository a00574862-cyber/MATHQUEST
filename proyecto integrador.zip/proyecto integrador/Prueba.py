# app_unica.py
import tkinter as tk
from tkinter import ttk, messagebox
import tkinter.font as tkfont
from PIL import Image, ImageTk
import os
import json
import random
import time

# -------------------------
# RUTAS Y UTILIDADES
# -------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")

def asset_path(filename):
    return os.path.join(ASSETS_DIR, filename)

# -------------------------
# ESTILO Y FUNCIONES COMUNES
# -------------------------
def estilo_boton(widget):
    widget.configure(
        background="#3b2f2f",
        foreground="#ffd700",
        font=("Terminal", 14, "bold"),
        activebackground="#5a3d2b",
        activeforeground="#fff",
        relief="ridge",
        borderwidth=4,
        width=20,
        height=2
    )

def cargar_usuarios():
    p = os.path.join(BASE_DIR, "usuarios.json")
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def guardar_usuarios(data):
    p = os.path.join(BASE_DIR, "usuarios.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def guardar_usuario_activo(usuario):
    p = os.path.join(BASE_DIR, "usuario_activo.txt")
    with open(p, "w", encoding="utf-8") as f:
        f.write(usuario)

def leer_usuario_activo():
    p = os.path.join(BASE_DIR, "usuario_activo.txt")
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            return f.read().strip()
    return None

# -------------------------
# NUEVO BLOQUE DE NIVELES
# -------------------------
NIVELES = {
    "tierra": {
        "nombre": "Nivel 1 [TIERRA]: Lógica y Razonamiento Básico",
        "fondo_color": "#c8e6c9",  # Verde claro
        "color_boton": "#4CAF50",  # Color del botón
        "preguntas": [
            {"texto": "", "respuesta": 6, "feedback": "3 + 3 = 6."},  # Eliminado el texto
            {"texto": "", "respuesta": 3, "feedback": "5 - 2 = 3."},  # Eliminado el texto
            {"texto": "", "respuesta": 2, "feedback": "4 - 2 = 2."},  # Eliminado el texto
            {"texto": "", "respuesta": 5, "feedback": "8 - 3 = 5."},  # Eliminado el texto
            {"texto": "", "respuesta": 4, "feedback": "2 x 2 = 4."}   # Eliminado el texto
        ],
        "fondo_preguntas": {
            0: r"assets/1_1.png",
            1: r"assets/1_2.png",
            2: r"assets/1_3.png",
            3: r"assets/1_4.png",
            4: r"assets/1_5.png"
        }
    },
    "piedra": {
        "nombre": "Nivel 2 [PIEDRA]: Lógica Intermedia",
        "fondo_color": "#d7ccc8",  # Gris-beige
        "color_boton": "#795548",  # Color del botón
        "preguntas": [
            {"texto": "", "respuesta": 21, "feedback": "7 x 3 = 21."},  # Eliminado el texto
            {"texto": "", "respuesta": "Sofía", "feedback": "Sofía fue la primera."},  # Eliminado el texto
            {"texto": "", "respuesta": 4, "feedback": "12 ÷ 3 = 4 días."},  # Eliminado el texto
            {"texto": "", "respuesta": 8, "feedback": "La secuencia suma 2 cada vez."},  # Eliminado el texto
            {"texto": "", "respuesta": 10, "feedback": "5 x 2 = 10 pesos."}   # Eliminado el texto
        ],
        "fondo_preguntas": {
            0: r"assets/2_1.png",
            1: r"assets/2_2.png",
            2: r"assets/2_3.png",
            3: r"assets/2_4.png",
            4: r"assets/2_5.png"
        }
    },
    "cueva": {
        "nombre": "Nivel 3 [CUEVA]: Razonamiento Avanzado",
        "fondo_color": "#bcaaa4",  # Gris oscuro
        "color_boton": "#616161",  # Color del botón
        "preguntas": [
            {"texto": "", "respuesta": 24, "feedback": "12 x 2 = 24."},  # Eliminado el texto
            {"texto": "", "respuesta": 8, "feedback": "24 ÷ 3 = 8."},  # Eliminado el texto
            {"texto": "", "respuesta": 15, "feedback": "50 - 35 = 15."},  # Eliminado el texto
            {"texto": "", "respuesta": "5:30", "feedback": "Llega a las 5:30 pm."},  # Eliminado el texto
            {"texto": "", "respuesta": 7, "feedback": "3 x 4 - 5 = 7."}   # Eliminado el texto
        ],
        "fondo_preguntas": {
            0: r"assets/3_1.png",
            1: r"assets/3_2.png",
            2: r"assets/3_3.png",
            3: r"assets/3_4.png",
            4: r"assets/3_5.png"
        }
    },
    "lava": {
        "nombre": "Nivel 4 [LAVA]: Lógica Compleja",
        "fondo_color": "#ffccbc",  # Naranja claro
        "color_boton": "#FF5722",  # Color del botón
        "preguntas": [
            {"texto": "", "respuesta": 27, "feedback": "100 - (25+18+30) = 27."},  # Eliminado el texto
            {"texto": "", "respuesta": "1/4", "feedback": "3/4 - 1/2 = 1/4."},  # Eliminado el texto
            {"texto": "", "respuesta": 5, "feedback": "28 ÷ 6 ≈ 5."},  # Eliminado el texto
            {"texto": "", "respuesta": 8, "feedback": "2000 ÷ 250 = 8."},  # Eliminado el texto
            {"texto": "", "respuesta": 46, "feedback": "3 x 18 = 54. 100 - 54 = 46."}  # Eliminado el texto
        ],
        "fondo_preguntas": {
            0: r"assets/4_1.png",
            1: r"assets/4_2.png",
            2: r"assets/4_3.png",
            3: r"assets/4_4.png",
            4: r"assets/4_5.png"
        }
    }
}

# ==================== FUNCIONES ====================

def guardar_progreso(usuario, nivel_key, puntaje, total):
    archivo = "progreso.json"
    if os.path.exists(archivo):
        with open(archivo, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = {}
    if usuario not in data:
        data[usuario] = {}
    data[usuario][nivel_key] = {"puntaje": puntaje, "total": total, "completado": puntaje == total}
    with open(archivo, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

# ==================== FUNCIONES DE INTERFAZ ====================

def abrir_menu_niveles(parent, usuario):
    win = tk.Toplevel(parent)
    win.title("⚔ Selecciona tu Nivel ⚔")
    win.geometry("1280x720")

    # Canvas para fondo e imágenes
    canvas = tk.Canvas(win, width=1280, height=720, highlightthickness=0)
    canvas.pack(fill="both", expand=True)

    # Fondo del menú
    fondo_menu_path = r"assets/menu.png"
    if os.path.exists(fondo_menu_path):
        img = Image.open(fondo_menu_path).resize((1280, 720), Image.LANCZOS)
        fondo_tk = ImageTk.PhotoImage(img)
        canvas.create_image(0, 0, image=fondo_tk, anchor="nw")
        win.fondo_tk = fondo_tk  # Para mantener referencia
    else:
        canvas.configure(bg="#1e1e2e")


    niveles_info = [
      
    ("🌱 Nivel 1 [TIERRA]: 🌿 Lógica y Razonamiento Básico 🌍", "tierra"),
    ("🪨 Nivel 2 [PIEDRA]: 🔨 Lógica Intermedia 💡", "piedra"),
    ("🦇 Nivel 3 [CUEVA]: 🏞️ Razonamiento Avanzado ⚡", "cueva"),
    ("🔥 Nivel 4 [LAVA]: 🌋 Lógica Compleja 🌟", "lava")
]

    

    def crear_boton_imagen(x, y, texto, nivel_key, color_boton):
        btn = tk.Button(win, text=texto, font=("Arial", 16, "bold"),
                        bg=color_boton, fg="white",
                        command=lambda: [win.destroy(), iniciar_nivel(parent, nivel_key, usuario)])
        btn_window = canvas.create_window(x, y, window=btn, anchor="center")
        return btn_window

    # Colocar botones verticalmente
    y_inicio = 180
    for i, (texto, clave) in enumerate(niveles_info):
        color_boton = NIVELES[clave]["color_boton"]
        crear_boton_imagen(640, y_inicio + i * 80, texto, clave, color_boton)

# ==================== INICIAR NIVEL ====================

def iniciar_nivel(parent, nivel_key, usuario):
    nivel = NIVELES[nivel_key]
    preguntas = nivel["preguntas"]  # Mantener en orden
    total = len(preguntas)

    win = tk.Toplevel(parent)
    win.title(nivel["nombre"])
    win.geometry("1280x720")

    pregunta_actual = 0
    puntaje = 0
    botones_actuales = []

    indicador = tk.Label(win, text=f"Pregunta {pregunta_actual + 1} de {total}",
                         font=("Arial", 14, "bold"), bg="white")
    indicador.place(relx=0.5, rely=0.05, anchor="center")

    canvas = tk.Canvas(win, width=1280, height=720, highlightthickness=0)
    canvas.pack(fill="both", expand=True)

    def mostrar_pregunta():
        nonlocal pregunta_actual
        # destruir botones anteriores
        for b in botones_actuales:
            b.destroy()
        botones_actuales.clear()

        if pregunta_actual >= total:
            guardar_progreso(usuario, nivel_key, puntaje, total)
            messagebox.showinfo("¡Felicidades!", f"Terminaste el nivel con {puntaje}/{total} correctas.")
            win.destroy()
            abrir_menu_niveles(parent, usuario)
            return

        p = preguntas[pregunta_actual]
        correcta = p["respuesta"]
        feedback = p["feedback"]

        indicador.config(text=f"Pregunta {pregunta_actual + 1} de {total}")

        # Fondo pregunta
        fondo_preg_path = nivel.get("fondo_preguntas", {}).get(pregunta_actual)
        if fondo_preg_path and os.path.exists(fondo_preg_path):
            img = Image.open(fondo_preg_path).resize((1280, 720), Image.LANCZOS)
            img_tk = ImageTk.PhotoImage(img)
            canvas.create_image(0, 0, image=img_tk, anchor="nw")
            win.img_tk = img_tk
        else:
            canvas.configure(bg=nivel["fondo_color"])

        # Opciones
        if isinstance(correcta, int):
            opciones = [correcta]
            while len(opciones) < 4:
                falsa = correcta + len(opciones)
                opciones.append(falsa)
        else:
            opciones = [correcta, "4:00", "5:00", "6:30", "1/2", "3/4", "20", "30"]
            opciones = [correcta] + [o for o in opciones if o != correcta][:3]

        # Botones de opciones estilo "videojuego" y organizados 2x2
        margen_x = 320
        margen_y = 350
        separacion_x = 600
        separacion_y = 100

        for i, opt in enumerate(opciones):
            col = i % 2
            row = i // 2
            btn = tk.Button(win, text=str(opt), font=("Arial", 14, "bold"), width=15, height=2,
                            bg=NIVELES[nivel_key]["color_boton"], fg="white", bd=3, relief="raised",
                            activebackground="#55efc4", activeforeground="black",
                            command=lambda o=opt: verificar(o, correcta, feedback))
            canvas.create_window(margen_x + col * separacion_x, margen_y + row * separacion_y, window=btn)
            botones_actuales.append(btn)

        # Botón salir
        salir_btn = tk.Button(win, text="🚪 Salir al Menú", font=("Arial", 12, "bold"),
                              bg="orange", command=lambda: [win.destroy(), abrir_menu_niveles(parent, usuario)])
        canvas.create_window(1140, 60, window=salir_btn)

    def verificar(seleccion, correcta, feedback):
        nonlocal pregunta_actual, puntaje
        if str(seleccion).strip() == str(correcta).strip():
            messagebox.showinfo("✅ Correcto", "¡Muy bien!")
            puntaje += 1
        else:
            messagebox.showwarning("❌ Incorrecto", feedback)
        pregunta_actual += 1
        mostrar_pregunta()

    mostrar_pregunta()

# (resto del código continúa igual)


# -------------------------
# CLASE NIVEL BASE (win_canvas.py content)
# -------------------------
class NivelBase:
    def __init__(self, root, cambiar_pantalla, nivel):
        self.root = root
        self.cambiar_pantalla = cambiar_pantalla
        self.nivel = nivel
        self.pregunta_actual = 1
        self.respuestas_correctas = 0

        self.frame = tk.Frame(root, bg="black")
        self.frame.pack(fill="both", expand=True)

        self.pixel_font = tkfont.Font(family="Courier", size=12, weight="bold")

        # Historias por nivel
        historias = {
            1: "¡El dragón ha robado las llaves del tesoro!\nResponde 10 sumas para recuperarlas.",
            2: "Los duendes han escondido las monedas mágicas.\nResuelve 10 restas para encontrarlas.",
            3: "El hechicero necesita ingredientes para su poción.\nMultiplica 10 veces para ayudarlo.",
            4: "Las hadas han dividido las estrellas del cielo.\nResuelve 10 divisiones para reunirlas.",
            5: "El rey necesita sumar sus tesoros.\nAyúdalo con 10 sumas grandes.",
            6: "El caballero debe multiplicar sus espadas mágicas.\nResuelve 10 multiplicaciones avanzadas."
        }

        tk.Label(
            self.frame,
            text=f"Nivel {nivel}",
            fg="#FFD700",
            bg="black",
            font=("Courier", 16, "bold")
        ).pack(pady=10)

        tk.Label(
            self.frame,
            text=historias[nivel],
            fg="#FFD700",
            bg="black",
            font=self.pixel_font,
            wraplength=700,
            justify="center"
        ).pack(pady=20)

        # Botón para comenzar
        tk.Button(
            self.frame,
            text="¡Comenzar Aventura!",
            bg="#FFD700",
            fg="black",
            font=self.pixel_font,
            command=self.generar_pregunta
        ).pack(pady=20)

        tk.Button(
            self.frame,
            text="Volver",
            bg="#FFD700",
            fg="black",
            font=self.pixel_font,
            command=lambda: cambiar_pantalla("niveles")
        ).pack(pady=10)

    def generar_pregunta(self):
        # Limpiar pantalla
        for widget in self.frame.winfo_children():
            widget.destroy()

        # Título del nivel
        titulos = {
            1: "Sumas hasta 10",
            2: "Restas hasta 20",
            3: "Multiplicaciones básicas",
            4: "Divisiones básicas",
            5: "Sumas hasta 100",
            6: "Multiplicaciones avanzadas"
        }
        tk.Label(
            self.frame,
            text=f"Nivel {self.nivel} - {titulos[self.nivel]}",
            fg="#FFD700",
            bg="black",
            font=self.pixel_font
        ).pack(pady=10)

        tk.Label(
            self.frame,
            text=f"Pregunta {self.pregunta_actual}/10",
            fg="#FFD700",
            bg="black",
            font=self.pixel_font
        ).pack(pady=5)

        # Generar pregunta según nivel
        if self.nivel == 1:
            a, b = random.randint(1, 5), random.randint(1, 5)
            self.correcta = a + b
            pregunta = f"{a} + {b} = ?"
        elif self.nivel == 2:
            a, b = random.randint(6, 10), random.randint(1, 5)
            self.correcta = a - b
            pregunta = f"{a} - {b} = ?"
        elif self.nivel == 3:
            a, b = random.randint(1, 10), random.randint(1, 10)
            self.correcta = a * b
            pregunta = f"{a} × {b} = ?"
        elif self.nivel == 4:
            resultado = random.randint(1, 10)
            b = random.randint(1, 10)
            a = resultado * b
            self.correcta = resultado
            pregunta = f"{a} ÷ {b} = ?"
        elif self.nivel == 5:
            a, b = random.randint(10, 50), random.randint(10, 50)
            self.correcta = a + b
            pregunta = f"{a} + {b} = ?"
        elif self.nivel == 6:
            a, b = random.randint(1, 12), random.randint(1, 12)
            self.correcta = a * b
            pregunta = f"{a} × {b} = ?"

        tk.Label(
            self.frame,
            text=pregunta,
            fg="#FFD700",
            bg="black",
            font=("Courier", 14, "bold")
        ).pack(pady=20)

        # Generar opciones
        opciones = {self.correcta}
        while len(opciones) < 4:
            if self.nivel <= 3:
                falso = random.randint(max(1, self.correcta - 10), self.correcta + 10)
            else:
                falso = random.randint(max(1, self.correcta - 20), self.correcta + 20)
            if falso != self.correcta:
                opciones.add(falso)
        opciones = list(opciones)
        random.shuffle(opciones)

        for op in opciones:
            tk.Button(
                self.frame,
                text=str(op),
                bg="#FFD700",
                fg="black",
                font=self.pixel_font,
                command=lambda val=op: self.verificar(val)
            ).pack(pady=8)

    def verificar(self, seleccion):
        if seleccion == self.correcta:
            self.respuestas_correctas += 1
            messagebox.showinfo("¡Correcto!", "¡Muy bien! 🎉")
        else:
            messagebox.showerror("Incorrecto", "Inténtalo de nuevo 💪")

        self.pregunta_actual += 1
        if self.pregunta_actual <= 10:
            self.generar_pregunta()
        else:
            self.completar_nivel()

    def completar_nivel(self):
        messagebox.showinfo("¡Nivel Completado!", f"Respuestas correctas: {self.respuestas_correctas}/10\n¡Has salvado el reino!")
        self.actualizar_progreso()
        self.cambiar_pantalla("niveles")

    def actualizar_progreso(self):
        usuario = leer_usuario_activo()
        if not usuario:
            return
        usuarios_file = os.path.join(BASE_DIR, "usuarios.json")
        if not os.path.exists(usuarios_file):
            return
        with open(usuarios_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        if usuario in data:
            data[usuario]["progreso"][f"nivel{self.nivel}"] = True
            with open(usuarios_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

# -------------------------
# FORMULARIOS (registro / login / portal)
# -------------------------
def open_form_nuevo(parent):
    win = tk.Toplevel(parent)
    win.title("🏰 Registro de Nuevo Héroe")
    win.geometry("750x550")
    win.config(bg="#1e1e2e")
    win.resizable(False, False)

    ttk.Label(win, text="⚔ Registra tu Personaje ⚔",
              font=("Terminal", 18, "bold"), background="#1e1e2e",
              foreground="#ffd700").pack(pady=20)

    frm = tk.Frame(win, bg="#1e1e2e")
    frm.pack(fill="both", expand=True, padx=40, pady=10)

    campos = [
        ("Usuario:", "usuario"),
        ("Contraseña:", "contra"),
        ("Nombre:", "nombre"),
        ("Edad:", "edad"),
        ("Grado escolar:", "grado"),
        ("Género:", "genero"),
        ("Fecha de nacimiento:", "fecha")
    ]

    entradas = {}
    for i, (label, key) in enumerate(campos):
        lbl = tk.Label(frm, text=label, bg="#1e1e2e", fg="#ffd700", font=("Terminal", 13))
        lbl.grid(row=i, column=0, sticky="w", pady=8, padx=10)
        show_char = "*" if key == "contra" else ""
        ent = tk.Entry(frm, width=35, show=show_char, bg="#2a2a3b", fg="#fff", font=("Consolas", 12))
        ent.grid(row=i, column=1, pady=8, padx=10)
        entradas[key] = ent

    # Habilidad matemática
    tk.Label(frm, text="Habilidad matemática:", bg="#1e1e2e",
             fg="#ffd700", font=("Terminal", 13)).grid(row=len(campos), column=0, sticky="w", pady=8, padx=10)
    habilidad_var = tk.StringVar(value="Básica")
    combo = ttk.Combobox(frm, textvariable=habilidad_var,
                         values=["Básica", "Media", "Avanzada"], state="readonly", width=32, font=("Consolas", 12))
    combo.grid(row=len(campos), column=1, pady=8, padx=10)

    def guardar():
        usuarios = cargar_usuarios()
        usuario = entradas["usuario"].get().strip()
        contra = entradas["contra"].get().strip()
        nombre = entradas["nombre"].get().strip()
        edad = entradas["edad"].get().strip()

        if not usuario or not contra or not nombre:
            messagebox.showerror("Error ⚠", "Faltan campos obligatorios.")
            return
        if not edad.isdigit():
            messagebox.showerror("Error ⚠", "La edad debe ser numérica.")
            return
        if usuario in usuarios:
            messagebox.showerror("Error ⚠", "Ese usuario ya existe.")
            return

        usuarios[usuario] = {
            "password": contra,
            "nombre": nombre,
            "edad": edad,
            "grado": entradas["grado"].get(),
            "genero": entradas["genero"].get(),
            "fecha_nacimiento": entradas["fecha"].get(),
            "habilidad": habilidad_var.get(),
            "progreso": {"nivel1": False, "nivel2": False, "nivel3": False, "nivel4": False}
        }

        guardar_usuarios(usuarios)
        messagebox.showinfo("Éxito 🏅", f"Tu registro ha sido guardado en el grimorio.\nBienvenido, {nombre}.")
        win.destroy()

    frame_botones = tk.Frame(win, bg="#1e1e2e")
    frame_botones.pack(pady=20)
    btn_guardar = tk.Button(frame_botones, text="💾 Guardar Registro", command=guardar)
    btn_cerrar = tk.Button(frame_botones, text="❌ Cerrar", command=win.destroy)
    estilo_boton(btn_guardar)
    estilo_boton(btn_cerrar)
    btn_guardar.grid(row=0, column=0, padx=20)
    btn_cerrar.grid(row=0, column=1, padx=20)

def open_form_registrado(parent):
    win = tk.Toplevel(parent)
    win.title("🛡 Ingreso de Aventurero")
    win.geometry("750x500")
    win.config(bg="#1e1e2e")
    win.resizable(False, False)

    ttk.Label(win, text="🔑 Inicia tu Aventura", font=("Terminal", 18, "bold"),
              background="#1e1e2e", foreground="#ffd700").pack(pady=30)

    frm = tk.Frame(win, bg="#1e1e2e")
    frm.pack(pady=30)

    tk.Label(frm, text="Usuario:", bg="#1e1e2e", fg="#ffd700",
             font=("Terminal", 14)).grid(row=0, column=0, sticky="w", pady=10, padx=10)
    ent_usuario = tk.Entry(frm, width=30, bg="#2a2a3b", fg="#fff", font=("Consolas", 13))
    ent_usuario.grid(row=0, column=1, pady=10, padx=10)

    tk.Label(frm, text="Contraseña:", bg="#1e1e2e", fg="#ffd700",
             font=("Terminal", 14)).grid(row=1, column=0, sticky="w", pady=10, padx=10)
    ent_contra = tk.Entry(frm, width=30, show="*", bg="#2a2a3b", fg="#fff", font=("Consolas", 13))
    ent_contra.grid(row=1, column=1, pady=10, padx=10)

    def validar():
        usuario = ent_usuario.get().strip()
        contra = ent_contra.get().strip()
        usuarios = cargar_usuarios()

        if not usuario or not contra:
            messagebox.showerror("Error ⚠", "Debes ingresar usuario y contraseña.")
            return

        if usuario in usuarios and usuarios[usuario]["password"] == contra:
            # Guardar usuario activo (archivo)
            guardar_usuario_activo(usuario)

            messagebox.showinfo("Bienvenido 🏰", f"Saludos, {usuario}. Tu aventura continúa.")

            # cerrar ventana de login
            win.destroy()

            # Abrir menú de niveles directamente
            abrir_menu_niveles(parent, usuario)
        else:
            messagebox.showerror("Error ⚠", "Usuario o contraseña incorrectos.")

    frame_botones = tk.Frame(win, bg="#1e1e2e")
    frame_botones.pack(pady=30)
    btn_ingresar = tk.Button(frame_botones, text="🗡 Ingresar", command=validar)
    btn_salir = tk.Button(frame_botones, text="❌ Cerrar", command=win.destroy)
    estilo_boton(btn_ingresar)
    estilo_boton(btn_salir)
    btn_ingresar.grid(row=0, column=0, padx=30)
    btn_salir.grid(row=0, column=1, padx=30)

def open_win_form(parent: tk.Tk = None):
    win = tk.Toplevel(parent) if parent else tk.Tk()
    win.title("⚔ Portal del Aventurero ⚔")
    win.geometry("900x600")
    win.config(bg="#1e1e2e")
    win.resizable(False, False)

    titulo = tk.Label(win, text="🏰 Bienvenido al Reino Digital 🏰",
                      bg="#1e1e2e", fg="#ffd700",
                      font=("Terminal", 24, "bold"))
    titulo.pack(pady=80)

    btn_nuevo = tk.Button(win, text="🧙‍♂ Crear Nuevo Héroe", command=lambda: open_form_nuevo(win))
    btn_registrado = tk.Button(win, text="🛡 Ingresar al Reino", command=lambda: open_form_registrado(win))
    estilo_boton(btn_nuevo)
    estilo_boton(btn_registrado)
    btn_nuevo.pack(pady=20)
    btn_registrado.pack(pady=20)

    # no hacemos mainloop aquí para permitir que main() lo gestione
    return win

# -------------------------
# MAIN (pantalla de inicio con fade)
# -------------------------
def fade_out(window, callback=None):
    """Desvanece lentamente la ventana antes de abrir otra."""
    try:
        alpha = window.attributes("-alpha")
    except Exception:
        alpha = 1.0
    if alpha > 0:
        alpha -= 0.05
        window.attributes("-alpha", alpha)
        window.after(25, lambda: fade_out(window, callback))
    else:
        if callback:
            callback()

def fade_in(window):
    try:
        alpha = window.attributes("-alpha")
    except Exception:
        alpha = 0.0
    if alpha < 1:
        alpha += 0.05
        window.attributes("-alpha", alpha)
        window.after(25, lambda: fade_in(window))

def main():
    root = tk.Tk()
    root.title("Addventure - Main Menu")
    root.geometry("1280x720")
    root.configure(bg="#020716")
    root.resizable(False, False)
    root.attributes("-alpha", 1.0)

    # Canvas principal
    canvas = tk.Canvas(root, width=1280, height=720, highlightthickness=0, bg="#020716")
    canvas.pack(fill="both", expand=True)

    # Cargar imágenes (si no existen, usamos botones simples)
    fondo_tk = None
    titulo_tk = None
    boton_tk = None

    fondo_path = asset_path("fondo_inicio.png")
    titulo_path = asset_path("titulo.png")
    boton_path = asset_path("boton_jugar.png")

    if os.path.exists(fondo_path):
        try:
            fondo_img = Image.open(fondo_path).resize((1280, 720), Image.Resampling.LANCZOS)
            fondo_tk = ImageTk.PhotoImage(fondo_img)
            canvas.create_image(0, 0, image=fondo_tk, anchor="nw")
        except Exception:
            pass

    if os.path.exists(titulo_path):
        try:
            titulo_img = Image.open(titulo_path).convert("RGBA")
            w, h = titulo_img.size
            scale_title = 0.63
            new_w = int(w * scale_title)
            new_h = int(h * scale_title)
            titulo_img = titulo_img.resize((new_w, new_h), Image.Resampling.LANCZOS)
            titulo_tk = ImageTk.PhotoImage(titulo_img)
            canvas.create_image(640, 330, image=titulo_tk, anchor="center")
        except Exception:
            pass

    if os.path.exists(boton_path):
        try:
            boton_img = Image.open(boton_path).convert("RGBA")
            bw, bh = boton_img.size
            scale_btn = 0.6
            new_bw = int(bw * scale_btn)
            new_bh = int(bh * scale_btn)
            boton_img = boton_img.resize((new_bw, new_bh), Image.Resampling.LANCZOS)
            boton_tk = ImageTk.PhotoImage(boton_img)
            boton_item = canvas.create_image(640, 460, image=boton_tk, anchor="center")

            def start_game(event=None):
                fade_out(root, lambda: [root.withdraw(), open_win_form(root)])

            canvas.tag_bind(boton_item, "<Button-1>", start_game)
        except Exception:
            # fallback to button
            btn = tk.Button(root, text="START", font=("Arial", 20, "bold"), bg="#0D47A1", fg="white",
                            command=lambda: fade_out(root, lambda: [root.withdraw(), open_win_form(root)]),
                            cursor="hand2")
            canvas.create_window(640, 460, window=btn, anchor="center")
    else:
        btn = tk.Button(root, text="START", font=("Arial", 20, "bold"), bg="#0D47A1", fg="white",
                        command=lambda: fade_out(root, lambda: [root.withdraw(), open_win_form(root)]),
                        cursor="hand2")
        canvas.create_window(640, 460, window=btn, anchor="center")

    # Mantener referencias para que no las recoja GC
    root._img_refs = (fondo_tk, titulo_tk, boton_tk)

    # Fade in
    root.attributes("-alpha", 0.0)
    fade_in(root)

    root.mainloop()

if __name__ == "__main__":
    main()